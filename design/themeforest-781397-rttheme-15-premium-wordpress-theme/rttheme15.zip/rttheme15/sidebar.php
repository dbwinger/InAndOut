<?php
#
# call sidebars
#
$createSidebars = new RT_Create_Sidebars();
$createSidebars -> rt_get_sidebar();
?>
