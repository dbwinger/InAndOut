<?php
/* 
* rt-theme 404 
*/
get_header();  
?>

<?php get_template_part( 'sub_page_header', 'sub_page_header_file' );?> 
	
 
			<h1 style="font-size:120px;">404</h1>
			<h6><?php _e( 'Apologies, but the page you requested could not be found. Perhaps searching will help.', 'rt_theme'); ?></h6><br /><br /><br />
    
<?php get_footer();?>