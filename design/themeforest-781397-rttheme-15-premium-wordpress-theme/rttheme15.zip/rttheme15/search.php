<?php
# 
# rt-theme search 
#
get_header();  
?>

<?php get_template_part( 'sub_page_header', 'sub_page_header_file' );?>

	<?php get_template_part( 'list_loop', 'archive' );?> 

    
<?php get_footer();?>